#include <WiFi.h>
#include <PubSubClient.h>
#include <Crypto.h>
#include <ChaCha.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// LCD setup: I2C address 0x27, 16x2
LiquidCrystal_I2C lcd(0x27, 16, 2);

#define BUZZER_PIN 18    // Active buzzer on GPIO27
#define RELAY_PIN 5 // ESP32 pin GPIO15, which connects to the pump the via the relay

// --- Encryption Key ---
static const uint8_t CHACHA_KEY[32] = {
  0x2a,0x91,0x7c,0x4d,0x9f,0x13,0x55,0x60,
  0x8a,0x01,0x22,0x4f,0xc7,0x3e,0x18,0xb2,
  0x9d,0x77,0x0a,0x46,0x51,0x3c,0x6e,0x99,
  0xf0,0xab,0x04,0x18,0x88,0x33,0x5c,0x71
};

// --- WiFi + MQTT ---
const char* ssid = "moto";
const char* password = "112233445566";
const char* mqtt_server = "10.234.3.129";
const char* topic = "test";

WiFiClient espClient;
PubSubClient client(espClient);

void setup_wifi() {
  delay(10);
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connected");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    if (client.connect("ESP32_Subscriber", "subs1", "1234")) {
      Serial.println("connected");
      client.subscribe(topic);
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5s");
      delay(5000);
    }
  }
}

// --- Simple parser functions ---
float extractFloat(const char* str, const char* key) {
  char* pos = strstr((char*)str, key);
  if (pos) {
    return atof(pos + strlen(key) + 2); // skip "key":
  }
  return 0;
}

int extractInt(const char* str, const char* key) {
  char* pos = strstr((char*)str, key);
  if (pos) {
    return atoi(pos + strlen(key) + 2);
  }
  return 0;
}

void callback(char* inTopic, byte* payload, unsigned int length) {
  Serial.print("\nMessage arrived on topic: ");
  Serial.println(inTopic);

  if (length < 8) {
    Serial.println("Payload too short!");
    return;
  }

  // --- Separate Nonce & Cipher ---
  uint8_t nonce[8];
  memcpy(nonce, payload, 8);
  const uint8_t* cipher = payload + 8;
  size_t cipherLen = length - 8;

  ChaCha chacha;
  chacha.setKey(CHACHA_KEY, sizeof(CHACHA_KEY));
  chacha.setIV(nonce, sizeof(nonce));

  uint8_t plain[cipherLen + 1];
  chacha.decrypt(plain, cipher, cipherLen);
  plain[cipherLen] = '\0';

 // --- Print Ciphertext in HEX ---
  Serial.print("Ciphertext: ");
  for (size_t i = 0; i < cipherLen; i++) {
    Serial.printf("%02X ", cipher[i]);  // prints each byte in HEX
  }
  Serial.println();

  Serial.print("Decrypted JSON: ");
  Serial.println((char*)plain);

  // --- Extract values ---
  float tempC = extractFloat((char*)plain, "TempC");
  float humidity = extractFloat((char*)plain, "Humidity");
  int moisture = extractInt((char*)plain, "Moisture");
  int modified_moisture = 0;
  int waterLevel = extractInt((char*)plain, "WaterLevel");

  // --- Display on LCD ---
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("T:");
  lcd.print(tempC, 1);
  lcd.print("C H:");
  lcd.print(humidity, 0);
  lcd.print("%");

  lcd.setCursor(0, 1);
  lcd.print("M:");
  lcd.print(moisture);
  lcd.print(" W:");
  lcd.print(waterLevel);

  // --- Buzzer control (water high) ---
  if (waterLevel > 100) { 
    tone(BUZZER_PIN, 1000); 
  } else {
    noTone(BUZZER_PIN);  
  }

  // --- Relay control (moisture low) ---
  if (moisture < 45) {  // threshold adjust as per soil type
    digitalWrite(RELAY_PIN, LOW);      // rotate to 90°
    Serial.println(digitalRead(RELAY_PIN));
  }else {
    digitalWrite(RELAY_PIN, HIGH);       // back to 0°
  }
}

void setup() {
  Serial.begin(115200);
  setup_wifi();
  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);
  pinMode(RELAY_PIN, OUTPUT);
  // LCD init
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Waiting for data");

  // Buzzer & Relay setup
  pinMode(BUZZER_PIN, OUTPUT);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();
}
