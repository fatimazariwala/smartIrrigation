#include <WiFi.h>
#include <PubSubClient.h>
#include <Crypto.h>
#include <ChaCha.h>
#include <DHT.h>

// --- Sensor Pin Definitions ---
#define PIN_DHT11       32   // DHT11 sensor (digital)
#define PIN_MOISTURE    34   // HW-080 soil moisture sensor (analog)
#define PIN_WATERLEVEL  35   // Water level sensor (analog)

// --- DHT11 Setup ---
#define DHTTYPE DHT11
DHT dht(PIN_DHT11, DHTTYPE);

// --- Encryption Key ---
static const uint8_t CHACHA_KEY[32] = {
  0x2a,0x91,0x7c,0x4d,0x9f,0x13,0x55,0x60,
  0x8a,0x01,0x22,0x4f,0xc7,0x3e,0x18,0xb2,
  0x9d,0x77,0x0a,0x46,0x51,0x3c,0x6e,0x99,
  0xf0,0xab,0x04,0x18,0x88,0x33,0x5c,0x71
};

// --- WiFi + MQTT ---
const char* ssid = "moto";
const char* password = "112233445566";
const char* mqtt_server = "10.234.3.129";
const char* topic = "test";

WiFiClient espClient;
PubSubClient client(espClient);

void setup_wifi() {
  delay(10);
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connected");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    if (client.connect("ESP32_Publisher")) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5s");
      delay(5000);
    }
  }
}

void chacha_encrypt_and_publish(const char* topic, const uint8_t* plain, size_t len) {
  uint8_t nonce[8];
  uint32_t r1 = esp_random();
  uint32_t r2 = esp_random();
  memcpy(nonce, &r1, 4);
  memcpy(nonce + 4, &r2, 4);

  ChaCha chacha;
  chacha.setKey(CHACHA_KEY, sizeof(CHACHA_KEY));
  chacha.setIV(nonce, sizeof(nonce));

  uint8_t cipher[len];
  chacha.encrypt(cipher, plain, len);

  Serial.print("Plaintext: ");
  Serial.write(plain, len);
  Serial.println();

  Serial.print("Ciphertext: ");
  for (size_t i = 0; i < len; i++) {
    Serial.printf("%02X ", cipher[i]);
  }
  Serial.println();

  uint8_t payload[8 + len];
  memcpy(payload, nonce, 8);
  memcpy(payload + 8, cipher, len);

  client.publish(topic, payload, sizeof(payload));
  Serial.println("Encrypted message published.\n");
}

void setup() {
  Serial.begin(115200);
  analogSetAttenuation(ADC_11db);

  dht.begin();  // Start DHT11 sensor
  setup_wifi();
  client.setServer(mqtt_server, 1883);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  // --- Read Temperature & Humidity from DHT11 ---
  float tempC = dht.readTemperature();
  float humidity = dht.readHumidity();

  if (isnan(tempC) || isnan(humidity)) {
    Serial.println("Failed to read from DHT11!");
    delay(2000);
    return;
  }

  // --- Read Soil Moisture (HW-080 analog 0–4095) ---
  int moistVal = analogRead(PIN_MOISTURE);
  int moistVal_modified = ( 100 - ( (moistVal/4095.00) * 100 ) );

  // --- Read Water Level Sensor (analog 0–4095) ---
  int waterLevel = analogRead(PIN_WATERLEVEL);
  int waterVolume = ((float)(waterLevel - 150) / (4000 - 150)) * 500;

  // --- Create JSON-like message ---
  char buffer[96];
  snprintf(buffer, sizeof(buffer), 
           "{\"TempC\":%.2f,\"Humidity\":%.2f,\"Moisture\":%d,\"WaterLevel\":%d}", 
           tempC, humidity, moistVal_modified, waterVolume);

  // --- Encrypt + Publish ---
  chacha_encrypt_and_publish(topic, (const uint8_t*)buffer, strlen(buffer));

  delay(5000);
}
